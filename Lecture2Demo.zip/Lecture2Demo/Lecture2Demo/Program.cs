﻿using ConsoleCustomName;
using static System.Console;

namespace Lecture2Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Hello World!");
        }
    }

    //public class Console
    //{
    //    public static void WriteLine(string value)
    //    {
    //        Console.WriteLine(value);
    //    }
    //}
}
